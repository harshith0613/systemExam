const Title = document.getElementById("title");
const description = document.getElementById('description');
const title1 = document.getElementById('title1');
const description1 = document.getElementById('description1')
const btn = document.getElementById('btn'); 
const date = document.getElementById("date");
 



function removeStylesFromDays() {
    for (let i = 1; i <= 7; i++) {
        const dayElement = document.getElementById(i.toString());
        if (dayElement) {
            dayElement.style.color = '';
            dayElement.style.fontSize = '';
            dayElement.style.backgroundColor = '';
        }
    }
}

function fun1() {
    title1.value = Title.value;
    description1.value = description.value;
    const selectedDay = date.value;
    removeStylesFromDays();


    const dayElement = document.getElementById(selectedDay);

    for(let i = 0; i <= 7; i++){
        if(date.value == i){
            dayElement.style.color = 'red';
            dayElement.style.fontSize = '16px';
            dayElement.style.backgroundColor = 'aqua';
        }
    }

}

btn.addEventListener('click', fun1)
